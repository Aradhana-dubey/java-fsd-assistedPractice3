package insertSortedCircularLinkedList;
class Node {
    int data;
    Node next;

    Node(int d) {
       this.data = d;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    CircularLinkedList() {
        this.head = null;
    }
    void insertSorted(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
            newNode.next = head;
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void printList() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }
}


public class insertSortedCircleLinkList {

	public static void main(String[] args) {
		 CircularLinkedList cL = new CircularLinkedList();

		 cL.insertSorted(15);
		 cL.insertSorted(14);
		 cL.insertSorted(2);
		 cL.insertSorted(6);

	        System.out.println("Circular Linked List after insertion:");
	        cL.printList();

	}

}
