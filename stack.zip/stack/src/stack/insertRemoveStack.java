package stack;
import java.util.Stack;
public class insertRemoveStack {

	public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        pushD(stack, 10);//insert element
        pushD(stack, 20);
        pushD(stack, 30);

        System.out.println("Stack elements: " + stack);

        popD(stack);//remove element
        
        System.out.println("Updated stack elements: " + stack);
    }

    private static void pushD(Stack<Integer> stack, int data) {
        System.out.println("Pushing element: " + data);
        stack.push(data);
    }

    private static void popD(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty. Cannot pop element.");
        } else {
            Integer popElement = stack.pop();
            System.out.println("Popped element: " + popElement);
        }

	}

}
