package rotateArray;
import java.util.Scanner;


public class rotateArray {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        int[] A = new int[size];
        int steps = 5;
        System.out.println("Enter the elements of the array:");

        for (int i = 0; i < size; i++) {
            A[i] = scanner.nextInt();
        }
	

        System.out.println("Original Array:");
        printA(A);

       rightRotateA(A, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps:");
        printA(A);
    }
    private static void rightRotateA(int[] B, int steps) {
        int length = B.length;
        steps = steps % length;

        reverseA(B, 0, length - 1);
        reverseA(B, 0, steps - 1);
        reverseA(B, steps, length - 1);
    }
    private static void reverseA(int[] C, int start, int end) {
        while (start < end) {
            int temp = C[start];
            C[start] = C[end];
            C[end] = temp;
            start++;
            end--;
        }
    }
    private static void printA(int[] D) {
        for (int num : D) {
            System.out.print(num + " ");
        }
        System.out.println();

	}

}
