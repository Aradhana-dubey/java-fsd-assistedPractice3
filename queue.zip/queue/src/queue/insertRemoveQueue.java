package queue;

import java.util.LinkedList;
import java.util.Queue;

public class insertRemoveQueue {

	public static void main(String[] args) {
		Queue<Integer> queue = new LinkedList<>();

 
		enqueueData(queue, 10);
		enqueueData(queue, 20);
		enqueueData(queue, 30);
		enqueueData(queue, 40);
		enqueueData(queue, 50);

        System.out.println("Queue elements: " + queue);

        dequeueData(queue);
        dequeueData(queue);

        System.out.println("Updated queue elements: " + queue);
    }

    private static void enqueueData(Queue<Integer> queue, int data) {
        System.out.println("Enqueue element: " + data);
        queue.add(data);
    }

    private static void dequeueData(Queue<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty.");
        } else {
            Integer dequeuedElement = queue.poll();
            System.out.println("Dequeued element: " + dequeuedElement);
        }

	}

}
