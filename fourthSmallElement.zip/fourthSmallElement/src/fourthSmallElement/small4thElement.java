package fourthSmallElement;
import java.util.Arrays;
import java.util.Scanner;

public class small4thElement {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        int[] A = new int[size];

        System.out.println("Enter the elements of the array:");

        for (int i = 0; i < size; i++) {
            A[i] = scanner.nextInt();
        }
	        
	        int fourthSmallest = getFourthSmallest(A);
	        
	        System.out.println("The fourth smallest element is: " + fourthSmallest);
	    }
	    private static int getFourthSmallest(int[] arr) {
	        if (arr.length < 4) {
	            System.out.println("List does not have enough elements.");
	        }
	         Arrays.sort(arr);
	        return arr[3];
	    }
	}