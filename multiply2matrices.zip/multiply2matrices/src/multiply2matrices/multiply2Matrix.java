package multiply2matrices;

public class multiply2Matrix {

    public static int[][] multiplyMatrices(int[][] A, int[][] B) {
        int rows1 = A.length;
        int cols1 = A[0].length;
        int rows2 = B.length;
        int cols2 = B[0].length;

        if (cols1 != rows2) {
            throw new IllegalArgumentException("Matrices cannot be multiplied: Number of columns in the first matrix must be equal to the number of rows in the second matrix");
        }

        int[][] result = new int[rows1][cols2];

        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols2; j++) {
                for (int k = 0; k < cols1; k++) {
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        return result;
    }

    public static void getMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int[][] A = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        int[][] B = {
            {9, 8, 7},
            {6, 5, 4},
            {3, 2, 1}
        };

        System.out.println("Matrix 1:");
        getMatrix(A);

        System.out.println("Matrix 2:");
        getMatrix(B);

        try {
            int[][] result = multiplyMatrices(A, B);

            System.out.println("Result of Matrix Multiplication:");
            getMatrix(result);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}