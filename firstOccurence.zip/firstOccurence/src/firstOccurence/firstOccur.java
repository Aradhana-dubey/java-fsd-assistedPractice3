package firstOccurence;
class Node {
    int data;
    Node next;

    Node(int d) {
        this.data = d;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    SinglyLinkedList() {
        this.head = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        if (current != null && current.data == key) {
            head = current.next;
            return;
        }
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
        if (current == null) {
            System.out.println("Key not found in the linked list");
            return;
        }
        prev.next = current.next;
    }

    // print linked list
    void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class firstOccur {

	public static void main(String[] args) {
		SinglyLinkedList sList = new SinglyLinkedList();

        // Insert elements
		sList.insert(50);
		sList.insert(20);
		sList.insert(30);
		sList.insert(70);

        System.out.println("Linked List before deletion:");
        sList.printList();

        int keyDelete = 20;
        sList.deleteKey(keyDelete);

        System.out.println("Linked List after deleting the first occurrence of " + keyDelete + ":");
        sList.printList();

	}

}
