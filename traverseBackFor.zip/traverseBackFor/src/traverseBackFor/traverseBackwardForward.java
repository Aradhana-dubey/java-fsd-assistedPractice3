package traverseBackFor;

class Node {
    int data;
    Node prev;
    Node next;

    Node(int d) {
        this.data = d;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    DoublyLinkedList() {
        this.head = null;
    }
    void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
        }
    }
    void forward() {
        Node temp = head;
        System.out.println("Doubly Linked List in Forward direction:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
    void backward() {
        Node temp = head;
        while (temp != null && temp.next != null) {
            temp = temp.next;
        }

        System.out.println("Doubly Linked List in Backward direction:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }
}

public class traverseBackwardForward {

	public static void main(String[] args) {
		DoublyLinkedList dList = new DoublyLinkedList();

        // Insert elements
		dList.insert(10);
		dList.insert(20);
		dList.insert(30);
		dList.insert(40);
		dList.forward();
		dList.backward();

	}

}
